#!/usr/bin/env bash

#export PYTHONPATH=.

python3 /tmp/sparkLambdaHandler.py
